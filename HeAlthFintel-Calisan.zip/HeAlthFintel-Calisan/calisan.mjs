import { createRequire } from 'module'; const require = createRequire(import.meta.url);

// apps/runner/src/main.ts
import { mkdtemp as mkdtemp2, writeFile as writeFile3 } from "node:fs/promises";
import { platform, tmpdir as tmpdir2 } from "node:os";
import { join as join3 } from "node:path";
import { chromium } from "playwright";

// apps/runner/src/api.ts
var AuthError = class extends Error {
};
var PanelApi = class {
  constructor(cfg) {
    this.cfg = cfg;
  }
  async req(path, init = {}) {
    let last;
    for (let attempt = 0; attempt < 4; attempt++) {
      try {
        const res = await fetch(`${this.cfg.panelUrl}${path}`, {
          method: init.method ?? "POST",
          headers: { authorization: `Bearer ${this.cfg.token}`, "content-type": "application/json" },
          body: init.body === void 0 ? void 0 : JSON.stringify(init.body),
          signal: AbortSignal.timeout(6e4)
        });
        if (res.status === 401) throw new AuthError("Ba\u011Flant\u0131 anahtar\u0131 ge\xE7ersiz.");
        if (!res.ok) throw new Error(`Panel ${res.status}`);
        return await res.json();
      } catch (e) {
        if (e instanceof AuthError) throw e;
        last = e;
        await new Promise((r) => setTimeout(r, 5e3 * (attempt + 1)));
      }
    }
    throw last;
  }
  hello(version, platform2) {
    return this.req("/api/runner/hello", { body: { version, platform: platform2 } });
  }
  status(s) {
    return this.req("/api/runner/status", { body: s });
  }
  poll(readOnly = false) {
    return this.req("/api/runner/poll", { body: { readOnly } });
  }
  result(jobId, r) {
    return this.req(`/api/runner/jobs/${encodeURIComponent(jobId)}`, { body: r });
  }
  file(fileId) {
    return this.req(`/api/runner/files/${encodeURIComponent(fileId)}`, { method: "GET" });
  }
};

// apps/runner/src/config.ts
import { mkdir, readFile, writeFile, rm } from "node:fs/promises";
import { homedir } from "node:os";
import { join } from "node:path";
import { createInterface } from "node:readline/promises";
import { stdin, stdout } from "node:process";
var HOME = join(homedir(), ".hfo-runner");
var PROFILE_DIR = join(HOME, "chrome-profili");
var LOG_DIR = join(HOME, "kayitlar");
var CONFIG_FILE = join(HOME, "ayarlar.json");
async function loadConfig() {
  await mkdir(HOME, { recursive: true });
  await mkdir(LOG_DIR, { recursive: true });
  const envPanel = (process.env.HFO_PANEL ?? "").trim().replace(/\/+$/, "");
  const envToken = (process.env.HFO_TOKEN ?? "").trim();
  if (/^https?:\/\/\S+$/.test(envPanel) && /^hfo_[A-Za-z0-9_-]{20,}$/.test(envToken)) return { panelUrl: envPanel, token: envToken };
  const keyFile = [join(process.cwd(), "anahtar.txt"), join(HOME, "anahtar.txt")];
  for (const f of keyFile) {
    const t = (await readFile(f, "utf8").catch(() => "")).trim().match(/hfo_[A-Za-z0-9_-]{20,}/)?.[0];
    const panel = "https://healthfintel-outreach.vercel.app".replace(/\/+$/, "");
    if (t && /^https?:\/\/\S+$/.test(panel)) {
      const c2 = { panelUrl: panel, token: t };
      await writeFile(CONFIG_FILE, JSON.stringify(c2, null, 2), { mode: 384 });
      await rm(f, { force: true });
      console.log("Anahtar anahtar.txt dosyas\u0131ndan okundu ve dosya silindi.");
      return c2;
    }
  }
  try {
    const c2 = JSON.parse(await readFile(CONFIG_FILE, "utf8"));
    if (c2.panelUrl && c2.token) return { panelUrl: c2.panelUrl, token: c2.token };
  } catch {
  }
  const rl = createInterface({ input: stdin, output: stdout });
  console.log("\n\u0130lk kurulum. Panelde LinkedIn hesaplar\u0131 sayfas\u0131ndan ba\u011Flant\u0131 anahtar\u0131 olu\u015Fturun.\n");
  let panelUrl = "https://healthfintel-outreach.vercel.app".replace(/\/+$/, "");
  if (panelUrl) console.log(`Panel: ${panelUrl}`);
  while (!/^https?:\/\/\S+$/.test(panelUrl)) panelUrl = (await rl.question("Panel adresi (\xF6r. https://outreach-ornek.vercel.app): ")).trim().replace(/\/+$/, "");
  let token = "";
  while (!/^hfo_[A-Za-z0-9_-]{20,}$/.test(token)) token = (await rl.question("Ba\u011Flant\u0131 anahtar\u0131n\u0131 yap\u0131\u015Ft\u0131r\u0131n (pencerede SA\u011E TIKLAYIN; yaz\u0131 g\xF6r\xFCnmez, Enter'a bas\u0131n): ")).trim();
  rl.close();
  const c = { panelUrl, token };
  await writeFile(CONFIG_FILE, JSON.stringify(c, null, 2), { mode: 384 });
  return c;
}
async function resetConfig() {
  await rm(CONFIG_FILE, { force: true });
}

// packages/core/src/companysearch.ts
var ABOUT_LABELS = [
  ["website", /^(web ?sitesi|website)$/i],
  ["industry", /^(sektör|industry)$/i],
  ["sizeText", /^(şirket büyüklüğü|company size)$/i],
  ["hq", /^(genel merkez|headquarters|merkez)$/i],
  ["founded", /^(kuruluş|founded|kuruluş yılı)$/i],
  ["specialties", /^(uzmanlık alanları|specialties|uzmanlıklar)$/i]
];
function parseAboutPairs(id, pairs) {
  const out = { id };
  for (const { label, value } of pairs) {
    const l = label.replace(/\s+/g, " ").trim();
    const v = value.replace(/\s+/g, " ").trim();
    if (!v) continue;
    const hit = ABOUT_LABELS.find(([, re]) => re.test(l));
    if (hit) out[hit[0]] = hit[0] === "website" ? v.replace(/[)\].,;]+$/, "") : v.slice(0, 300);
  }
  if (!out.website && !out.industry && !out.sizeText && !out.hq && !out.founded && !out.specialties) out.empty = true;
  return out;
}

// packages/core/src/schedule.ts
var DEFAULT_SCHEDULE = {
  weeklyInvites: 180,
  activeDays: [0, 1, 2, 3, 4, 5, 6],
  windowStartMin: 9 * 60,
  windowEndMin: 18 * 60 + 30,
  minGapMin: 4,
  maxGapMin: 20,
  utcOffsetMin: 180
};

// packages/core/src/discovery.ts
function canonicalProfileUrl(url) {
  const m = url.trim().match(/linkedin\.com\/(in|sales\/lead|sales\/people)\/([^/?#,]+)/i);
  if (!m) return null;
  let slug = m[2];
  try {
    slug = decodeURIComponent(slug);
  } catch {
  }
  return `https://www.linkedin.com/in/${slug.toLocaleLowerCase("tr-TR")}`;
}

// packages/core/src/sequence.ts
var ATTACHMENT_RULES = {
  maxBytes: 10 * 1024 * 1024,
  allowed: ["application/pdf"]
};
var H = 36e5;
var D = 24 * H;

// packages/core/src/dispatch.ts
var MIN = 6e4;
var DAY = 24 * 60 * MIN;

// packages/core/src/panel.ts
var UNDO_WINDOW_MS = 10 * 6e4;

// apps/runner/src/linkedin/actions.ts
import { mkdtemp, rm as rm2, writeFile as writeFile2 } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join as join2 } from "node:path";

// apps/runner/src/linkedin/util.ts
var JobError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
};
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
var pause = (minMs, maxMs) => sleep(minMs + Math.random() * (maxMs - minMs));
var anyText = (...texts) => new RegExp(`^\\s*(${texts.map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|")})\\s*$`, "i");
var containsText = (...texts) => new RegExp(`(${texts.map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|")})`, "i");
async function guard(page) {
  const url = page.url();
  if (/\/(login|uas\/login|authwall|signup)/.test(url)) throw new JobError("session_expired", "LinkedIn oturumu kapand\u0131.");
  if (/\/checkpoint\//.test(url)) throw new JobError("linkedin_warning", "LinkedIn do\u011Frulama istedi (checkpoint). Taray\u0131c\u0131 penceresinde kontrol edin.");
  const restricted = await page.getByText(containsText("account has been restricted", "hesab\u0131n\u0131z k\u0131s\u0131tland\u0131", "unusual activity", "ola\u011Fand\u0131\u015F\u0131 etkinlik")).first().isVisible({ timeout: 500 }).catch(() => false);
  if (restricted) throw new JobError("linkedin_warning", "LinkedIn hesapta ola\u011Fand\u0131\u015F\u0131 etkinlik uyar\u0131s\u0131 g\xF6sterdi.");
}
async function open(page, url) {
  const res = await page.goto(url, { waitUntil: "domcontentloaded", timeout: 45e3 });
  await pause(1500, 3500);
  await guard(page);
  if (res && res.status() === 404) throw new JobError("not_found", "Sayfa bulunamad\u0131.");
  const unavailable = await page.getByText(containsText("This page doesn\u2019t exist", "This page doesn't exist", "Bu sayfa mevcut de\u011Fil", "profile is not available", "profil kullan\u0131lam\u0131yor")).first().isVisible({ timeout: 800 }).catch(() => false);
  if (unavailable) throw new JobError("not_found", "Profil bulunamad\u0131 ya da kald\u0131r\u0131lm\u0131\u015F.");
  await page.mouse.wheel(0, 200 + Math.random() * 400).catch(() => void 0);
  await pause(600, 1500);
}
async function firstVisible(...locs) {
  for (const l of locs) {
    const n = await l.count().catch(() => 0);
    for (let i = 0; i < Math.min(n, 6); i++) {
      const el = l.nth(i);
      if (await el.isVisible().catch(() => false)) return el;
    }
  }
  return null;
}
async function click(l) {
  await l.scrollIntoViewIfNeeded().catch(() => void 0);
  await pause(300, 900);
  await l.click({ timeout: 1e4 });
  await pause(800, 1800);
}
async function typeText(page, box, text) {
  await box.click();
  await pause(300, 700);
  const lines = text.split("\n");
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line) {
      const head = line.slice(0, 8);
      for (const ch of head) await page.keyboard.type(ch, { delay: 40 + Math.random() * 80 });
      if (line.length > 8) await page.keyboard.insertText(line.slice(8));
    }
    if (i < lines.length - 1) {
      await page.keyboard.down("Shift");
      await page.keyboard.press("Enter");
      await page.keyboard.up("Shift");
    }
    await pause(80, 250);
  }
}
function relativeToDate(text, now = /* @__PURE__ */ new Date()) {
  const t = text.toLocaleLowerCase("tr-TR");
  const n = Number(t.match(/(\d+)/)?.[1] ?? 1);
  const DAY2 = 864e5;
  if (/(dakika|minute|saat|hour|bugün|today|şimdi|now)/.test(t)) return now;
  if (/(dün|yesterday)/.test(t)) return new Date(now.getTime() - DAY2);
  if (/(gün|day)/.test(t)) return new Date(now.getTime() - n * DAY2);
  if (/(hafta|week)/.test(t)) return new Date(now.getTime() - n * 7 * DAY2);
  if (/(ay|month)/.test(t)) return new Date(now.getTime() - n * 30 * DAY2);
  return now;
}

// apps/runner/src/linkedin/actions.ts
async function isLoggedIn(page) {
  await page.goto("https://www.linkedin.com/feed/", { waitUntil: "domcontentloaded", timeout: 45e3 }).catch(() => void 0);
  await pause(1500, 2500);
  const url = page.url();
  return url.includes("linkedin.com/feed") && !/(login|authwall|checkpoint)/.test(url);
}
async function readSelf(page) {
  await open(page, "https://www.linkedin.com/in/me/");
  const profileUrl = canonicalProfileUrl(page.url()) ?? void 0;
  const fullName = (await page.locator("main h1").first().innerText({ timeout: 1e4 }).catch(() => ""))?.trim() || void 0;
  const premium = await page.locator("main").getByText(containsText("Premium")).first().isVisible({ timeout: 1500 }).catch(() => false);
  const schools = await readEducation(page);
  return { fullName, profileUrl, premium, schools };
}
async function readEducation(page) {
  const section = page.locator("section:has(#education)");
  if (!await section.count().catch(() => 0)) return [];
  const names = await section.locator("li a[href*='/company/'] span[aria-hidden='true'], li a[href*='/school/'] span[aria-hidden='true'], li div.t-bold span[aria-hidden='true']").allInnerTexts().catch(() => []);
  return [...new Set(names.map((n) => n.trim()).filter((n) => n.length > 2))].slice(0, 8);
}
var DEGREE_RE = /(?:^|\s|·|•)(1|2|3)(?:\.|st|nd|rd|th)(?:\s|$)/;
async function visitProfile(page, url, opts) {
  await open(page, url);
  const top = page.locator("main section").first();
  const fullName = (await page.locator("main h1").first().innerText({ timeout: 15e3 }).catch(() => ""))?.trim() || void 0;
  if (!fullName) throw new JobError("transient", "Profil sayfas\u0131 okunamad\u0131.");
  const topText = await top.innerText().catch(() => "") ?? "";
  const lines = topText.split("\n").map((l) => l.trim()).filter(Boolean);
  const nameIdx = lines.findIndex((l) => l === fullName);
  const after = nameIdx >= 0 ? lines.slice(nameIdx + 1) : lines;
  const degreeLine = after.find((l) => DEGREE_RE.test(` ${l} `) && l.length < 20);
  const degree = degreeLine ? Number(DEGREE_RE.exec(` ${degreeLine} `)[1]) : void 0;
  const headline = after.find((l) => l.length > 3 && !DEGREE_RE.test(` ${l} `) && !/^(she|he|they|o)\s*\//i.test(l) && l !== "\xB7");
  const location = after.find((l, i) => i > 0 && /,/.test(l) && l.length < 80 && l !== headline && !/bağlantı|connection|takipçi|follower/i.test(l));
  const company = await top.locator("button[aria-label*='Current company'], button[aria-label*='\u015Eu anki \u015Firket'], button[aria-label*='Mevcut \u015Firket']").first().getAttribute("aria-label", { timeout: 1500 }).then((a) => a?.replace(/^.*?:\s*/, "").replace(/\.\s*Click.*$/i, "").trim() || void 0).catch(() => void 0);
  const mutualText = lines.find((l) => /ortak bağlantı|mutual connection/i.test(l));
  let mutualName;
  let mutualConnections;
  if (mutualText) {
    mutualName = mutualText.split(/,| ve | and /)[0]?.trim();
    if (mutualName && (/\d/.test(mutualName) || /ortak|mutual/i.test(mutualName))) mutualName = void 0;
    const more = Number(mutualText.match(/(\d+)\s*(diğer|other)/i)?.[1] ?? 0);
    const named = mutualText.split(/,| ve | and /).filter((x) => !/\d|ortak|mutual/i.test(x)).length;
    mutualConnections = named + more || void 0;
  }
  const invitePending = !!await firstVisible(top.getByRole("button", { name: containsText("Pending", "Beklemede") }));
  const openProfile = /open profile|açık profil/i.test(topText) || void 0;
  const about = await page.locator("section:has(#about) span[aria-hidden='true']").first().innerText({ timeout: 1500 }).then((t) => t.slice(0, 600)).catch(() => void 0);
  let sharedSchool;
  if (opts.readEducation && opts.mySchools.length) {
    const theirs = await readEducation(page);
    const fold2 = (s) => s.toLocaleLowerCase("tr-TR").replace(/\s+/g, " ").trim();
    sharedSchool = theirs.find((t) => opts.mySchools.some((m) => fold2(m) === fold2(t)));
  }
  let recentPostText;
  if (opts.readPost && degree !== void 0) {
    const base = (canonicalProfileUrl(url) ?? url).replace(/\/$/, "");
    await open(page, `${base}/recent-activity/all/`);
    const post = await page.locator("div.feed-shared-update-v2 .update-components-text, div.feed-shared-update-v2 span.break-words").first().innerText({ timeout: 4e3 }).catch(() => void 0);
    const when = await page.locator("div.feed-shared-update-v2 .update-components-actor__sub-description").first().innerText({ timeout: 1500 }).catch(() => "");
    if (post && relativeToDate(when).getTime() > Date.now() - 30 * 864e5) recentPostText = post.slice(0, 1e3);
  }
  return { fullName, headline, location, company, degree, mutualName, mutualConnections, invitePending, openProfile, about, sharedSchool, recentPostText };
}
async function topCard(page) {
  return page.locator("main section").first();
}
async function sendInvite(page, url, note) {
  await open(page, url);
  const card = await topCard(page);
  if (await firstVisible(card.getByRole("button", { name: containsText("Pending", "Beklemede") }))) return { status: "already_pending" };
  let connect = await firstVisible(
    card.getByRole("button", { name: containsText("Invite", "davet et", "ba\u011Flant\u0131 kurmak i\xE7in davet") }),
    card.getByRole("button", { name: anyText("Connect", "Ba\u011Flant\u0131 kur") })
  );
  if (!connect) {
    const more = await firstVisible(card.getByRole("button", { name: containsText("More actions", "More", "Di\u011Fer i\u015Flemler", "Di\u011Fer") }));
    if (more) {
      await click(more);
      connect = await firstVisible(
        page.getByRole("button", { name: containsText("Invite", "davet et") }),
        page.locator("div[role='button'][aria-label*='Invite'], div[role='button'][aria-label*='davet']"),
        page.getByRole("menuitem", { name: containsText("Connect", "Ba\u011Flant\u0131 kur") })
      );
    }
  }
  if (!connect) {
    const isConnection = !!await firstVisible(card.getByRole("button", { name: containsText("Remove connection", "Ba\u011Flant\u0131y\u0131 kald\u0131r") }));
    const firstDegree = /(?:^|\s)1(?:\.|st)(?:\s|$)/.test(` ${await card.innerText().catch(() => "") ?? ""} `);
    if (isConnection || firstDegree) return { status: "already_connected" };
    throw new JobError("cannot_message", "Bu profilde davet d\xFC\u011Fmesi yok (yaln\u0131zca takip edilebiliyor olabilir).");
  }
  await click(connect);
  const dialog = page.getByRole("dialog").last();
  await dialog.waitFor({ state: "visible", timeout: 1e4 }).catch(() => void 0);
  await checkInviteLimits(page);
  if (await dialog.getByText(containsText("email address", "e-posta adres")).first().isVisible({ timeout: 800 }).catch(() => false)) {
    await page.keyboard.press("Escape");
    throw new JobError("cannot_message", "LinkedIn bu ki\u015Fiye davet i\xE7in e-posta adresi istiyor.");
  }
  if (note) {
    const addNote = await firstVisible(dialog.getByRole("button", { name: containsText("Add a note", "Not ekle") }));
    if (addNote) await click(addNote);
    const box = await firstVisible(dialog.locator("textarea[name='message']"), dialog.locator("textarea"));
    if (!box) {
      await page.keyboard.press("Escape");
      throw new JobError("transient", "Davet notu eklenemedi (ayl\u0131k not s\u0131n\u0131r\u0131 dolmu\u015F olabilir).");
    }
    await typeText(page, box, note);
    await pause(800, 1600);
    const send = await firstVisible(dialog.getByRole("button", { name: anyText("Send", "G\xF6nder", "Send invitation", "Davet g\xF6nder") }));
    if (!send || await send.isDisabled()) throw new JobError("transient", "G\xF6nder d\xFC\u011Fmesi bulunamad\u0131.");
    await click(send);
  } else {
    const send = await firstVisible(
      dialog.getByRole("button", { name: containsText("Send without a note", "Not olmadan g\xF6nder", "Notsuz g\xF6nder") }),
      dialog.getByRole("button", { name: anyText("Send", "G\xF6nder") })
    );
    if (!send) throw new JobError("transient", "G\xF6nder d\xFC\u011Fmesi bulunamad\u0131.");
    await click(send);
  }
  await pause(1500, 2500);
  await checkInviteLimits(page);
  const pending = await firstVisible((await topCard(page)).getByRole("button", { name: containsText("Pending", "Beklemede") }));
  if (!pending) {
    await page.reload({ waitUntil: "domcontentloaded" });
    await pause(2e3, 3e3);
    if (!await firstVisible((await topCard(page)).getByRole("button", { name: containsText("Pending", "Beklemede") })))
      throw new JobError("transient", "Davetin gitti\u011Fi do\u011Frulanamad\u0131.");
  }
  return { status: "sent" };
}
async function checkInviteLimits(page) {
  const limit = await page.getByText(containsText("weekly invitation limit", "haftal\u0131k davet s\u0131n\u0131r\u0131", "reached the weekly", "too many pending invitations", "\xE7ok fazla bekleyen davet")).first().isVisible({ timeout: 800 }).catch(() => false);
  if (limit) {
    await page.keyboard.press("Escape").catch(() => void 0);
    throw new JobError("invite_limit", "LinkedIn haftal\u0131k davet s\u0131n\u0131r\u0131na ula\u015F\u0131ld\u0131\u011F\u0131n\u0131 bildirdi.");
  }
}
async function downloadAttachment(fetchUrl) {
  const { url, name } = await fetchUrl();
  const res = await fetch(url, { signal: AbortSignal.timeout(6e4) });
  if (!res.ok) throw new JobError("transient", "Belge indirilemedi.");
  const dir = await mkdtemp(join2(tmpdir(), "hfo-"));
  const path = join2(dir, name.replace(/[\\/:*?"<>|]+/g, "-") || "belge.pdf");
  await writeFile2(path, Buffer.from(await res.arrayBuffer()));
  return { path, cleanup: () => rm2(dir, { recursive: true, force: true }) };
}
async function sendMessage(page, url, text, opts) {
  await open(page, url);
  const card = await topCard(page);
  const msgBtn = await firstVisible(card.getByRole("button", { name: containsText("Message", "Mesaj") }), card.getByRole("link", { name: containsText("Message", "Mesaj") }));
  if (!msgBtn) throw new JobError("cannot_message", "Bu ki\u015Fiye mesaj g\xF6nderilemiyor (Mesaj d\xFC\u011Fmesi yok).");
  await closeOpenConversations(page);
  await click(msgBtn);
  const form = page.locator("form.msg-form, div.msg-form, .msg-overlay-conversation-bubble form").last();
  const box = await (async () => {
    for (let i = 0; i < 10; i++) {
      const b = await firstVisible(page.locator("div.msg-form__contenteditable[contenteditable='true']"), page.locator("div[role='textbox'][contenteditable='true']"));
      if (b) return b;
      await pause(700, 900);
    }
    return null;
  })();
  if (!box) {
    if (await page.getByText(containsText("Premium", "InMail")).first().isVisible({ timeout: 800 }).catch(() => false))
      throw new JobError("cannot_message", "Bu ki\u015Fiye yaln\u0131zca InMail ile yaz\u0131labiliyor.");
    throw new JobError("transient", "Mesaj kutusu a\xE7\u0131lmad\u0131.");
  }
  let creditsLeft;
  const subject = await firstVisible(page.locator("input[name='subject']"), page.getByPlaceholder(containsText("Subject", "Konu")));
  if (subject) {
    if (opts.requireConnection) throw new JobError("cannot_message", "Ki\u015Fi ba\u011Flant\u0131 de\u011Fil; mesaj yerine InMail gerekir.");
    const creditText = await page.getByText(/(\d+)\s*(InMail credits|InMail kredi)/i).first().innerText({ timeout: 800 }).catch(() => "");
    const m = creditText.match(/(\d+)/);
    if (m) creditsLeft = Math.max(0, Number(m[1]) - 1);
    await typeText(page, subject, opts.subject ?? "K\u0131sa bir tan\u0131\u015Fma");
  }
  const head = text.slice(0, 60).trim();
  const already = await page.locator(".msg-s-event-listitem__body, .msg-s-message-list__event").filter({ hasText: head }).count().catch(() => 0);
  if (already > 0) return { creditsLeft };
  await typeText(page, box, text);
  let cleanup;
  if (opts.attachment) {
    const file = await downloadAttachment(opts.attachment);
    cleanup = file.cleanup;
    const input = page.locator("input[type='file']").last();
    await input.setInputFiles(file.path);
    for (let i = 0; i < 30; i++) {
      const uploading = await page.locator(".msg-attachment-preview__progress, [role='progressbar']").count().catch(() => 0);
      if (!uploading) break;
      await pause(900, 1100);
    }
    await pause(1e3, 2e3);
  }
  const send = await firstVisible(page.locator("button.msg-form__send-button"), form.getByRole("button", { name: anyText("Send", "G\xF6nder") }));
  try {
    if (!send) throw new JobError("transient", "G\xF6nder d\xFC\u011Fmesi bulunamad\u0131.");
    if (await send.isDisabled()) throw new JobError("transient", "G\xF6nder d\xFC\u011Fmesi pasif.");
    await click(send);
    let ok = false;
    for (let i = 0; i < 12 && !ok; i++) {
      await pause(800, 1e3);
      ok = await page.locator(".msg-s-event-listitem__body, .msg-s-message-list__event").filter({ hasText: head }).count().catch(() => 0) > 0;
    }
    await guard(page);
    if (!ok) throw new JobError("transient", "Mesaj\u0131n gitti\u011Fi do\u011Frulanamad\u0131.");
  } finally {
    await cleanup?.();
    await closeOpenConversations(page);
  }
  return { creditsLeft };
}
async function closeOpenConversations(page) {
  const closers = page.locator("button[data-control-name='overlay.close_conversation_window'], .msg-overlay-bubble-header__controls button:has(svg[data-test-icon='close-small'])");
  const n = await closers.count().catch(() => 0);
  for (let i = n - 1; i >= 0; i--) await closers.nth(i).click({ timeout: 3e3 }).catch(() => void 0);
}
async function withdrawInvite(page, url) {
  await open(page, url);
  const card = await topCard(page);
  const pending = await firstVisible(card.getByRole("button", { name: containsText("Pending", "Beklemede", "Withdraw", "Geri \xE7ek") }));
  if (!pending) return;
  await click(pending);
  const confirm = await firstVisible(page.getByRole("dialog").last().getByRole("button", { name: anyText("Withdraw", "Geri \xE7ek") }));
  if (!confirm) throw new JobError("transient", "Geri \xE7ekme onay\u0131 bulunamad\u0131.");
  await click(confirm);
}
async function recentConnections(page, limit) {
  await open(page, "https://www.linkedin.com/mynetwork/invite-connect/connections/");
  const hrefs = await page.locator("main a[href*='/in/']").evaluateAll((as) => as.map((a) => a.href));
  const urls = [...new Set(hrefs.map((h) => canonicalProfileUrl(h)).filter((u) => !!u))];
  return { profileUrls: urls.slice(0, limit) };
}
async function sentInvites(page) {
  await open(page, "https://www.linkedin.com/mynetwork/invitation-manager/sent/");
  const items = await page.locator("main li").evaluateAll(
    (lis) => lis.map((li) => {
      const a = li.querySelector("a[href*='/in/']");
      return a ? { href: a.href, text: li.innerText } : null;
    }).filter((x) => !!x)
  );
  const now = /* @__PURE__ */ new Date();
  const invites = items.map((i) => {
    const url = canonicalProfileUrl(i.href);
    const when = i.text.split("\n").find((l) => /(önce|ago|gönderildi|sent)/i.test(l)) ?? "";
    return url ? { profileUrl: url, sentAt: relativeToDate(when, now).toISOString() } : null;
  }).filter((x) => !!x);
  return { invites };
}
async function readInbox(page, limit, myName, seen) {
  await open(page, "https://www.linkedin.com/messaging/");
  const items = page.locator("li.msg-conversation-listitem, li.msg-conversations-container__convo-item");
  const n = Math.min(limit, await items.count().catch(() => 0));
  const threads = [];
  for (let i = 0; i < n; i++) {
    const item = items.nth(i);
    const summary = (await item.innerText().catch(() => "") ?? "").replace(/\s+/g, " ").trim();
    const key = summary.slice(0, 80);
    const sig = summary;
    if (seen.get(key) === sig) continue;
    await item.locator("a, div[role='button']").first().click({ timeout: 5e3 }).catch(() => item.click());
    await pause(1500, 2500);
    await guard(page);
    const profileHref = await page.locator(".msg-thread a[href*='/in/'], .msg-entity-lockup a[href*='/in/'], .msg-title-bar a[href*='/in/']").first().getAttribute("href", { timeout: 3e3 }).catch(() => null);
    const profileUrl = profileHref ? canonicalProfileUrl(new URL(profileHref, "https://www.linkedin.com").href) : null;
    if (!profileUrl) {
      seen.set(key, sig);
      continue;
    }
    const events = await page.locator("li.msg-s-message-list__event").evaluateAll((lis) => {
      let sender = "";
      return lis.map((li) => {
        const name = li.querySelector(".msg-s-message-group__name, .msg-s-message-group__profile-link")?.innerText?.trim();
        if (name) sender = name;
        const time = li.querySelector("time")?.getAttribute("datetime") ?? "";
        const body = li.querySelector(".msg-s-event-listitem__body")?.innerText?.trim() ?? "";
        return { sender, body, time };
      });
    });
    const myFirst = (myName ?? "").split(" ")[0]?.toLocaleLowerCase("tr-TR");
    threads.push({
      profileUrl,
      messages: events.filter((e) => e.body).slice(-15).map((e) => ({
        fromMe: !!myFirst && e.sender.toLocaleLowerCase("tr-TR").startsWith(myFirst),
        text: e.body,
        at: e.time || (/* @__PURE__ */ new Date()).toISOString()
      }))
    });
    seen.set(key, sig);
    await pause(800, 1600);
  }
  return { threads };
}
var GENERIC = /* @__PURE__ */ new Set(["ozel", "hastanesi", "hastane", "hospital", "klinigi", "klinik", "clinic", "medical", "center", "merkezi", "merkez", "tip", "saglik", "as", "a", "s", "ltd", "sti", "sirketi", "ve", "ticaret", "sanayi", "grubu", "group", "sigorta", "hayat", "emeklilik"]);
var norm = (x) => x.toLocaleLowerCase("tr-TR").replace(/ı/g, "i").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9 ]+/g, " ").replace(/\s+/g, " ").trim();
function mentionsCompany(text, label) {
  const name = label.split("\xB7").slice(1).join("\xB7");
  const core = norm(name).split(" ").filter((w) => w.length > 1 && !GENERIC.has(w));
  if (!core.length) return true;
  const hay = ` ${norm(text)} `;
  return core.every((w) => hay.includes(` ${w}`));
}
async function readPeople(page) {
  return retryNav(
    page,
    () => page.evaluate(() => {
      const root = document.querySelector("main") ?? document.body;
      const best = /* @__PURE__ */ new Map();
      for (const el of Array.from(root.querySelectorAll("[role='listitem'], li"))) {
        const links = Array.from(el.querySelectorAll("a[href*='/in/']"));
        const a = links.find((x) => (x.innerText ?? "").trim());
        if (!a) continue;
        const path = new URL(a.href).pathname.split("/").slice(0, 3).join("/");
        const text = el.innerText ?? "";
        const others = new Set(links.map((x) => new URL(x.href).pathname.split("/").slice(0, 3).join("/")));
        if (others.size > 6) continue;
        const name = ((a.innerText ?? "").split("\n").map((x) => x.trim()).find(Boolean) ?? "").replace(/\s*[•·]\s*(?:1|2|3)(?:\.|st|nd|rd|\+)?.*$/, "").trim();
        if (!name) continue;
        const cur = best.get(path);
        if (!cur || text.length < cur.text.length) best.set(path, { href: a.href, name, text });
      }
      return Array.from(best.values());
    })
  ).catch(() => null);
}
async function discover(page, steps, viewBudget) {
  const candidates = [];
  const report = [];
  let viewed = 0;
  for (const step of steps) {
    if (viewed >= viewBudget) break;
    let stepViewed = 0;
    let stepFound = 0;
    let pageBase = step.url;
    for (let p = 1; p <= step.maxPages && viewed < viewBudget; p++) {
      const url = p === 1 ? pageBase : `${pageBase}&page=${p}`;
      await open(page, url);
      await page.mouse.wheel(0, 1500).catch(() => void 0);
      await pause(1200, 2200);
      let rows = await readPeople(page);
      if (!rows?.length && p === 1 && step.source === "accounts") {
        const kw = new URL(step.url).searchParams.get("keywords") ?? "";
        const name = /AND ("[^"]+")\s*$/.exec(kw)?.[1];
        if (name) {
          await dumpDebug(page, "kisi-arama-bos");
          const alt = new URL(step.url);
          alt.searchParams.set("keywords", name);
          await open(page, alt.toString());
          await page.mouse.wheel(0, 1500).catch(() => void 0);
          await pause(1200, 2200);
          rows = await readPeople(page);
          if (rows?.length) pageBase = alt.toString();
        }
      }
      if (!rows?.length && p === 1) await dumpDebug(page, "kisi-arama-bos");
      if (!rows?.length) break;
      viewed += rows.length;
      stepViewed += rows.length;
      for (const r of rows) {
        if (step.source === "accounts" && !mentionsCompany(r.text, step.label)) continue;
        const url2 = canonicalProfileUrl(r.href);
        if (!url2 || /linkedin member|linkedin üyesi/i.test(r.name)) continue;
        const lines = r.text.split("\n").map((l) => l.trim()).filter((l) => l && l !== r.name && !/^(view|profili görüntüle)/i.test(l) && l !== "\u2022");
        const degLine = lines.find((l) => DEGREE_RE.test(` ${l} `) && l.length < 25);
        const degree = degLine ? Number(DEGREE_RE.exec(` ${degLine} `)[1]) : step.source === "connections" ? 1 : void 0;
        const rest = lines.filter((l) => l !== degLine && !/^(connect|bağlantı kur|message|mesaj|follow|takip et|pending|beklemede)$/i.test(l));
        const mutualLine = rest.find((l) => /ortak bağlantı|mutual connection/i.test(l));
        const content = rest.filter((l) => l !== mutualLine && !/^(current|şu an|past|geçmiş):/i.test(l));
        candidates.push({
          profileUrl: url2,
          fullName: r.name,
          headline: content[0],
          location: content[1],
          degree,
          mutualConnections: mutualLine ? Number(mutualLine.match(/(\d+)/)?.[1] ?? 1) : void 0,
          source: step.source
        });
        stepFound++;
      }
      await pause(3500, 8e3);
    }
    report.push({ label: step.label, viewed: stepViewed, found: stepFound });
  }
  return { candidates, viewed, steps: report };
}
async function dumpDebug(page, name) {
  try {
    const info = await page.evaluate(() => {
      const root = document.querySelector("main") ?? document.body;
      const links = Array.from(root.querySelectorAll("a")).map((a) => a.href).filter(Boolean);
      return {
        title: document.title,
        text: root.innerText.slice(0, 2500),
        linkCount: links.length,
        companyLinks: links.filter((h) => h.includes("/company/")).slice(0, 15),
        sampleLinks: links.slice(0, 25),
        listItems: root.querySelectorAll("li").length,
        firstHtml: root.innerHTML.slice(0, 3e3)
      };
    });
    await writeFile2(join2(LOG_DIR, `${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}-${name}.txt`), `${page.url()}

${JSON.stringify(info, null, 2)}`);
  } catch {
  }
}
async function retryNav(page, fn, tries = 3) {
  for (let i = 1; ; i++) {
    try {
      return await fn();
    } catch (e) {
      const msg = e instanceof Error ? e.message : "";
      if (i >= tries || !/execution context|navigat|target closed/i.test(msg)) throw e;
      await page.waitForLoadState("domcontentloaded", { timeout: 15e3 }).catch(() => void 0);
      await pause(1500, 2500);
    }
  }
}
async function discoverCompanies(page, queries, deadlineMs = 6 * 6e4) {
  const t0 = Date.now();
  const companies = [];
  const seen = /* @__PURE__ */ new Set();
  const report = [];
  let viewed = 0;
  const readCards = () => retryNav(
    page,
    () => page.evaluate(() => {
      const root = document.querySelector("main") ?? document.body;
      const links = Array.from(root.querySelectorAll("a[href*='/company/']"));
      const out = [];
      const seen2 = /* @__PURE__ */ new Set();
      for (const a of links) {
        const path = new URL(a.href).pathname.split("/").slice(0, 3).join("/");
        if (seen2.has(path)) continue;
        const label = (a.innerText || a.getAttribute("aria-label") || "").split("\n").map((x) => x.trim()).find(Boolean) ?? "";
        let card = a;
        for (let i = 0; i < 6 && card.parentElement && card.parentElement !== root; i++) {
          const par = card.parentElement;
          const others = Array.from(par.querySelectorAll("a[href*='/company/']")).filter((x) => new URL(x.href).pathname.split("/").slice(0, 3).join("/") !== path);
          if (others.length || (par.innerText ?? "").length > 700) break;
          card = par;
        }
        const name = label || (card.innerText ?? "").split("\n").map((x) => x.trim()).find(Boolean) || "";
        if (!name) continue;
        seen2.add(path);
        out.push({ href: a.href, name, text: card.innerText ?? "" });
      }
      return out;
    })
  ).catch(() => null);
  for (const q of queries) {
    let found = 0;
    let pageBase = q.url;
    for (let p = 1; p <= q.maxPages; p++) {
      if (Date.now() - t0 > deadlineMs) break;
      await open(page, p === 1 ? pageBase : `${pageBase}&page=${p}`);
      await page.mouse.wheel(0, 1500).catch(() => void 0);
      await pause(1200, 2200);
      let rows = await readCards();
      if (!rows?.length && p === 1) {
        const u = new URL(q.url);
        const variants = [];
        const noGeo = new URL(u);
        noGeo.searchParams.delete("companyHqGeo");
        variants.push(noGeo.toString());
        const words = (u.searchParams.get("keywords") ?? "").split(" ");
        if (words.length > 1) {
          const short = new URL(noGeo);
          short.searchParams.set("keywords", words.slice(0, -1).join(" "));
          variants.push(short.toString());
        }
        for (const v of variants) {
          await dumpDebug(page, "sirket-arama-bos");
          await open(page, v);
          await page.mouse.wheel(0, 1500).catch(() => void 0);
          await pause(1200, 2200);
          rows = await readCards();
          if (rows?.length) {
            pageBase = v;
            break;
          }
        }
      }
      if (!rows?.length && p === 1) await dumpDebug(page, "sirket-arama-bos");
      if (!rows?.length) break;
      viewed += rows.length;
      for (const r of rows) {
        const key = r.href.split("?")[0];
        if (seen.has(key)) continue;
        seen.add(key);
        companies.push({ linkedinUrl: r.href, name: r.name, text: r.text });
        found++;
      }
      await pause(3500, 8e3);
    }
    report.push({ label: q.label, found });
  }
  return { companies, viewed, queries: report };
}
async function enrichCompanies(page, companies, deadlineMs = 6 * 6e4) {
  const t0 = Date.now();
  const items = [];
  for (const c of companies) {
    if (Date.now() - t0 > deadlineMs) break;
    await open(page, `${c.url.replace(/\/+$/, "")}/about/`);
    await pause(1200, 2200);
    const pairs = await retryNav(page, () => page.locator("main dl").evaluateAll(
      (dls) => dls.flatMap((dl) => {
        const out = [];
        let label = "";
        for (const el of Array.from(dl.children)) {
          if (el.tagName === "DT") label = el.innerText ?? "";
          else if (el.tagName === "DD" && label) {
            const a = el.querySelector("a[href^='http']");
            const href = a?.href ?? "";
            let value = el.innerText ?? "";
            if (/^(web ?sitesi|website)$/i.test(label.trim()) && href) {
              try {
                const u = new URL(href);
                value = u.searchParams.get("url") ?? href;
              } catch {
                value = href;
              }
            }
            out.push({ label, value });
          }
        }
        return out;
      })
    )).catch(() => []);
    items.push(parseAboutPairs(c.id, pairs));
    await pause(3500, 8e3);
  }
  return { items };
}

// apps/runner/src/main.ts
var VERSION = "0.1.0";
var PLATFORM = platform() === "win32" ? "Windows" : platform() === "darwin" ? "Mac" : "Linux";
var MIN_SEND_GAP_MS = 45e3;
var JOB_TIMEOUT_MS = 8 * 6e4;
var log = (...a) => console.log((/* @__PURE__ */ new Date()).toLocaleTimeString("tr-TR"), ...a);
async function launchCloud() {
  const dir = await mkdtemp2(join3(tmpdir2(), "hfo-"));
  const ctx = await chromium.launchPersistentContext(dir, {
    headless: true,
    viewport: { width: 1280, height: 860 },
    locale: "tr-TR",
    timezoneId: "Europe/Istanbul",
    userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
    args: ["--disable-blink-features=AutomationControlled"]
  });
  const li = (process.env.LI_AT ?? "").trim();
  if (li) await ctx.addCookies([{ name: "li_at", value: li, domain: ".linkedin.com", path: "/", secure: true, httpOnly: true, sameSite: "None" }]);
  return ctx;
}
async function launch() {
  const opts = {
    headless: false,
    viewport: { width: 1280, height: 860 },
    locale: "tr-TR",
    timezoneId: "Europe/Istanbul",
    args: ["--disable-blink-features=AutomationControlled"]
  };
  try {
    return await chromium.launchPersistentContext(PROFILE_DIR, { ...opts, channel: "chrome" });
  } catch (e) {
    console.error("\nGoogle Chrome ba\u015Flat\u0131lamad\u0131. Chrome kurulu de\u011Filse https://www.google.com/chrome adresinden kurun.");
    console.error("Chrome kuruluysa ve bu hata s\xFCr\xFCyorsa: Chrome'un ba\u015Fka bir 'chrome-profili' penceresi a\xE7\u0131k olmad\u0131\u011F\u0131ndan emin olun.\n");
    throw e;
  }
}
async function waitForLogin(page, api) {
  if (await isLoggedIn(page)) return;
  await api.status({ loggedIn: false }).catch(() => void 0);
  await page.goto("https://www.linkedin.com/login", { waitUntil: "domcontentloaded" }).catch(() => void 0);
  console.log("\n>>> A\xE7\u0131lan Chrome penceresinde LinkedIn'e giri\u015F yap\u0131n. \u015Eifreniz bu program taraf\u0131ndan okunmaz ve saklanmaz.");
  console.log(">>> Giri\u015F yapt\u0131ktan sonra bu pencere kendili\u011Finden devam eder.\n");
  for (; ; ) {
    await sleep(1e4);
    const url = page.url();
    if (url.includes("linkedin.com/feed") || url.includes("linkedin.com/in/")) break;
    if (!/linkedin\.com\/(login|checkpoint|uas|authwall)/.test(url) && url.includes("linkedin.com")) {
      if (await isLoggedIn(page)) break;
    }
  }
  log("LinkedIn oturumu a\xE7\u0131k.");
}
async function shot(page, name) {
  const base = join3(LOG_DIR, `${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}-${name}`);
  await page.screenshot({ path: `${base}.png`, fullPage: false }).catch(() => void 0);
  await writeFile3(`${base}.url.txt`, page.url()).catch(() => void 0);
}
async function runJob(page, api, self, job, inboxSeen) {
  const p = job.payload;
  switch (p.type) {
    case "VISIT_PROFILE":
      return { ok: true, data: await visitProfile(page, p.profileUrl, { readPost: p.readPost, readEducation: p.readEducation, mySchools: self.schools }) };
    case "SEND_INVITE":
      return { ok: true, data: await sendInvite(page, p.profileUrl, p.note) };
    case "SEND_MESSAGE":
      await sendMessage(page, p.profileUrl, p.text, {
        attachment: p.attachment ? () => api.file(p.attachment.fileId) : void 0,
        // Açık profil dışında mesaj yalnızca bağlantılara gider; InMail kredisi yanlışlıkla harcanmaz
        requireConnection: !p.viaOpenProfile,
        subject: p.viaOpenProfile ? "K\u0131sa bir tan\u0131\u015Fma" : void 0
      });
      return { ok: true };
    case "SEND_INMAIL":
      return { ok: true, data: await sendMessage(page, p.profileUrl, p.text, { subject: p.subject }) };
    case "WITHDRAW_INVITE":
      await withdrawInvite(page, p.profileUrl);
      return { ok: true };
    case "CHECK_CONNECTIONS":
      return { ok: true, data: await recentConnections(page, p.limit) };
    case "CHECK_INBOX":
      return { ok: true, data: await readInbox(page, p.limit, self.fullName, inboxSeen) };
    case "SYNC_SENT_INVITES":
      return { ok: true, data: await sentInvites(page) };
    case "DISCOVER":
      return { ok: true, data: await discover(page, p.steps, p.viewBudget) };
    case "DISCOVER_COMPANIES": {
      const data = await discoverCompanies(page, p.queries);
      log(`  ${data.companies.length} \u015Firket okundu (${data.queries.map((q) => `${q.label}: ${q.found}`).join(", ")})`);
      if (!data.companies.length) log("  Hi\xE7 \u015Firket kart\u0131 okunamad\u0131; 'kayitlar' klas\xF6r\xFCne sayfa d\xF6k\xFCm\xFC yaz\u0131ld\u0131.");
      await writeFile3(join3(LOG_DIR, `${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}-sirket-arama-ozet.txt`), JSON.stringify({ queries: data.queries, sample: data.companies.slice(0, 5) }, null, 2)).catch(() => void 0);
      return { ok: true, data };
    }
    case "ENRICH_COMPANIES":
      return { ok: true, data: await enrichCompanies(page, p.companies) };
  }
}
var withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new JobError("transient", "\u0130\u015F zaman a\u015F\u0131m\u0131na u\u011Frad\u0131.")), ms))]);
async function main() {
  const args = process.argv.slice(2);
  if (args.includes("--sifirla")) {
    await resetConfig();
    console.log("Ba\u011Flant\u0131 anahtar\u0131 silindi. Yeniden ba\u015Flat\u0131nca sorulacak.");
    return;
  }
  const cfg = await loadConfig();
  const api = new PanelApi(cfg);
  const me = await api.hello(VERSION, PLATFORM).catch((e) => {
    if (e instanceof AuthError) {
      console.error("\nBa\u011Flant\u0131 anahtar\u0131 ge\xE7ersiz. Panelden yeni anahtar olu\u015Fturup 'pnpm runner --sifirla' ile yeniden girin.\n");
      process.exit(1);
    }
    throw e;
  });
  log(`Panele ba\u011Fland\u0131: ${me.displayName}`);
  const cloud = args.includes("--bulut");
  const ctx = cloud ? await launchCloud() : await launch();
  let page = ctx.pages()[0] ?? await ctx.newPage();
  let stopping = false;
  const stop = async () => {
    if (stopping) return;
    stopping = true;
    log("Kapat\u0131l\u0131yor\u2026");
    await ctx.close().catch(() => void 0);
    process.exit(0);
  };
  process.on("SIGINT", stop);
  process.on("SIGTERM", stop);
  ctx.on("close", () => {
    if (!stopping) {
      log("Chrome penceresi kapat\u0131ld\u0131; \xE7al\u0131\u015Fan durdu.");
      process.exit(0);
    }
  });
  if (cloud) {
    if (!await isLoggedIn(page)) {
      await api.status({ loggedIn: false }).catch(() => void 0);
      console.error("LinkedIn oturumu a\xE7\u0131lamad\u0131: LI_AT \xE7erezi ge\xE7ersiz ya da s\xFCresi dolmu\u015F. Yenisini GitHub gizli de\u011Fi\u015Fkenlerine ekleyin.");
      await ctx.close().catch(() => void 0);
      process.exit(2);
    }
  } else await waitForLogin(page, api);
  const self = await readSelf(page).catch(() => ({ schools: [] }));
  await api.status({ loggedIn: true, profileUrl: self.profileUrl, premium: self.premium });
  log(`Hesap: ${self.fullName ?? "okunamad\u0131"}${self.premium ? " (Premium)" : ""}`);
  if (args.includes("--kontrol")) {
    console.log("\nKontrol tamam. Profil okundu:", { ad: self.fullName, premium: self.premium, okullar: self.schools });
    await stop();
    return;
  }
  const inboxSeen = /* @__PURE__ */ new Map();
  let lastSendAt = 0;
  let lastLoginCheck = Date.now();
  const deadline = cloud ? Date.now() + (Number(process.env.HFO_BULUT_DAKIKA) || 20) * 6e4 : Number.POSITIVE_INFINITY;
  let idle = 0;
  if (cloud) log("Bulut modu: yaln\u0131zca arama i\u015Fleri al\u0131n\u0131r (davet ve mesaj g\xF6nderilmez).");
  log("\xC7al\u0131\u015F\u0131yor. Bu pencereyi ve Chrome'u a\xE7\u0131k b\u0131rak\u0131n; bilgisayar uykuya ge\xE7erse i\u015Fler a\xE7\u0131l\u0131nca devam eder.");
  setInterval(() => void api.hello(VERSION, PLATFORM).catch(() => void 0), 6e4).unref();
  while (!stopping) {
    if (Date.now() > deadline) {
      log("Bulut s\xFCresi doldu; kapat\u0131l\u0131yor.");
      await stop();
    }
    try {
      if (!cloud && Date.now() - lastLoginCheck > 30 * 6e4) {
        lastLoginCheck = Date.now();
        if (!await isLoggedIn(page)) {
          await waitForLogin(page, api);
          await api.status({ loggedIn: true, profileUrl: self.profileUrl });
        }
      }
      const res = await api.poll(cloud);
      if (cloud && res.account.status === "NEEDS_LOGIN") {
        log("Hesap oturum bekliyor; bulut \xE7al\u0131\u015Fan\u0131 durdu.");
        await stop();
      }
      if (res.account.status === "NEEDS_LOGIN") {
        if (await isLoggedIn(page)) await api.status({ loggedIn: true, profileUrl: self.profileUrl });
        else await waitForLogin(page, api);
        continue;
      }
      if (!res.job) {
        if (cloud && ++idle >= 3) {
          log("S\u0131rada i\u015F yok; kapat\u0131l\u0131yor.");
          await stop();
        }
        await sleep(res.sleepSec * 1e3);
        continue;
      }
      idle = 0;
      const job = res.job;
      const sending = ["SEND_INVITE", "SEND_MESSAGE", "SEND_INMAIL", "WITHDRAW_INVITE"].includes(job.payload.type);
      if (sending) {
        const wait = lastSendAt + MIN_SEND_GAP_MS + Math.random() * 3e4 - Date.now();
        if (wait > 0) await sleep(wait);
      }
      log(`\u0130\u015F: ${job.payload.type}${"profileUrl" in job.payload ? ` \xB7 ${job.payload.profileUrl}` : ""}`);
      let result;
      try {
        result = await withTimeout(runJob(page, api, self, job, inboxSeen), JOB_TIMEOUT_MS);
      } catch (e) {
        const err = e instanceof JobError ? e : new JobError("transient", e instanceof Error ? e.message : String(e));
        if (err.code === "transient" || err.code === "linkedin_warning") await shot(page, job.payload.type);
        result = { ok: false, error: err.code, message: err.message };
        log(`  sonu\xE7: hata (${err.code}) ${err.message}`);
        if (/zaman aşımı/.test(err.message)) {
          const old = page;
          page = await ctx.newPage();
          await old.close().catch(() => void 0);
        }
      }
      if (result.ok) log("  sonu\xE7: tamam");
      if (sending) lastSendAt = Date.now();
      await api.result(job.id, result);
      if (!result.ok && (result.error === "linkedin_warning" || result.error === "invite_limit")) {
        log("LinkedIn uyar\u0131s\u0131 nedeniyle g\xF6nderim 24 saat duraklat\u0131ld\u0131. L\xFCtfen LinkedIn'i taray\u0131c\u0131dan kontrol edin.");
      }
      await pause(3e3, 9e3);
    } catch (e) {
      if (e instanceof AuthError) {
        console.error("\nBa\u011Flant\u0131 anahtar\u0131 ge\xE7ersiz oldu (panelde yenilenmi\u015F olabilir). 'pnpm runner --sifirla' ile yeni anahtar\u0131 girin.\n");
        await stop();
        return;
      }
      log("Ba\u011Flant\u0131 sorunu; 1 dakika sonra tekrar denenecek.", e instanceof Error ? e.message : e);
      await sleep(6e4);
    }
  }
}
main().catch((e) => {
  console.error(e);
  process.exit(1);
});
